﻿namespace erptest1
{
    partial class Home
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle49 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle50 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle51 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea7 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend7 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea8 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend8 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series8 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle52 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle53 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle54 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle55 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle56 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle57 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle58 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle59 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle60 = new System.Windows.Forms.DataGridViewCellStyle();
            this.SidePanel = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.button_Notice = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.button_plan = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button_search = new System.Windows.Forms.Button();
            this.LogoPanel = new System.Windows.Forms.Panel();
            this.page2_Input = new System.Windows.Forms.Panel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.metroDateTime2 = new MetroFramework.Controls.MetroDateTime();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.metroGrid2 = new MetroFramework.Controls.MetroGrid();
            this.metroDateTime3 = new MetroFramework.Controls.MetroDateTime();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Smart = new System.Windows.Forms.Label();
            this.HeadPanel = new System.Windows.Forms.Panel();
            this.User = new MetroFramework.Controls.MetroLabel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            this.metroStyleExtender1 = new MetroFramework.Components.MetroStyleExtender(this.components);
            this.page1_Search = new System.Windows.Forms.Panel();
            this.Page_SearchTab = new MetroFramework.Controls.MetroTabControl();
            this.Production_History = new MetroFramework.Controls.MetroTabPage();
            this.ProductGrid = new MetroFramework.Controls.MetroGrid();
            this.SerialSearch = new System.Windows.Forms.Button();
            this.SerialNum = new System.Windows.Forms.TextBox();
            this.ProductDateTime = new MetroFramework.Controls.MetroDateTime();
            this.MonthlyStatus = new MetroFramework.Controls.MetroTabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.MonthlyProductionChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.SelectYear = new System.Windows.Forms.ComboBox();
            this.dailyStatus = new MetroFramework.Controls.MetroTabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.dailyProductionChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.SelectMonth = new System.Windows.Forms.ComboBox();
            this.ProductionName = new MetroFramework.Controls.MetroTabPage();
            this.buttonRefresh = new System.Windows.Forms.Button();
            this.ProductNameGrid = new MetroFramework.Controls.MetroGrid();
            this.label7 = new System.Windows.Forms.Label();
            this.page2_line = new System.Windows.Forms.Panel();
            this.Page_planTab = new MetroFramework.Controls.MetroTabControl();
            this.PlanInsert = new MetroFramework.Controls.MetroTabPage();
            this.Delete_Plan = new System.Windows.Forms.Button();
            this.SelectProductionLine = new MetroFramework.Controls.MetroComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.LinePlanGrid = new MetroFramework.Controls.MetroGrid();
            this.button2 = new System.Windows.Forms.Button();
            this.Line_num = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Line_Product = new MetroFramework.Controls.MetroComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Operating_situation = new MetroFramework.Controls.MetroTabPage();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Page0_Notice = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.NoticeNote = new System.Windows.Forms.RichTextBox();
            this.NoticeSend = new System.Windows.Forms.Button();
            this.NoticeGrid = new MetroFramework.Controls.MetroGrid();
            this.SidePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.LogoPanel.SuspendLayout();
            this.page2_Input.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.HeadPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.page1_Search.SuspendLayout();
            this.Page_SearchTab.SuspendLayout();
            this.Production_History.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ProductGrid)).BeginInit();
            this.MonthlyStatus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MonthlyProductionChart)).BeginInit();
            this.dailyStatus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dailyProductionChart)).BeginInit();
            this.ProductionName.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ProductNameGrid)).BeginInit();
            this.page2_line.SuspendLayout();
            this.Page_planTab.SuspendLayout();
            this.PlanInsert.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LinePlanGrid)).BeginInit();
            this.Operating_situation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.Page0_Notice.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NoticeGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // SidePanel
            // 
            this.SidePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(65)))));
            this.SidePanel.Controls.Add(this.pictureBox4);
            this.SidePanel.Controls.Add(this.button_Notice);
            this.SidePanel.Controls.Add(this.pictureBox3);
            this.SidePanel.Controls.Add(this.button_plan);
            this.SidePanel.Controls.Add(this.pictureBox2);
            this.SidePanel.Controls.Add(this.button_search);
            this.SidePanel.Controls.Add(this.LogoPanel);
            this.SidePanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.SidePanel.Location = new System.Drawing.Point(0, 0);
            this.SidePanel.Name = "SidePanel";
            this.SidePanel.Size = new System.Drawing.Size(204, 552);
            this.SidePanel.TabIndex = 0;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(21, 153);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(38, 37);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 8;
            this.pictureBox4.TabStop = false;
            // 
            // button_Notice
            // 
            this.button_Notice.FlatAppearance.BorderSize = 0;
            this.button_Notice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Notice.Font = new System.Drawing.Font("맑은 고딕", 13F);
            this.button_Notice.ForeColor = System.Drawing.Color.White;
            this.button_Notice.Location = new System.Drawing.Point(-1, 138);
            this.button_Notice.Name = "button_Notice";
            this.button_Notice.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button_Notice.Size = new System.Drawing.Size(205, 65);
            this.button_Notice.TabIndex = 7;
            this.button_Notice.Text = "   공지 사항";
            this.button_Notice.UseVisualStyleBackColor = true;
            this.button_Notice.Click += new System.EventHandler(this.button_Notice_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(20, 295);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(38, 37);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            // 
            // button_plan
            // 
            this.button_plan.FlatAppearance.BorderSize = 0;
            this.button_plan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_plan.Font = new System.Drawing.Font("맑은 고딕", 13F);
            this.button_plan.ForeColor = System.Drawing.Color.White;
            this.button_plan.Location = new System.Drawing.Point(-1, 280);
            this.button_plan.Name = "button_plan";
            this.button_plan.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button_plan.Size = new System.Drawing.Size(205, 65);
            this.button_plan.TabIndex = 5;
            this.button_plan.Text = "   생산 계획";
            this.button_plan.UseVisualStyleBackColor = true;
            this.button_plan.Click += new System.EventHandler(this.button_plan_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(20, 224);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(38, 37);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // button_search
            // 
            this.button_search.FlatAppearance.BorderSize = 0;
            this.button_search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_search.Font = new System.Drawing.Font("맑은 고딕", 13F);
            this.button_search.ForeColor = System.Drawing.Color.White;
            this.button_search.Location = new System.Drawing.Point(-1, 209);
            this.button_search.Name = "button_search";
            this.button_search.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button_search.Size = new System.Drawing.Size(205, 65);
            this.button_search.TabIndex = 3;
            this.button_search.Text = "   생산 조회";
            this.button_search.UseVisualStyleBackColor = true;
            this.button_search.Click += new System.EventHandler(this.button2_Click);
            // 
            // LogoPanel
            // 
            this.LogoPanel.BackColor = System.Drawing.Color.SlateGray;
            this.LogoPanel.Controls.Add(this.page2_Input);
            this.LogoPanel.Controls.Add(this.panel1);
            this.LogoPanel.Controls.Add(this.pictureBox1);
            this.LogoPanel.Controls.Add(this.Smart);
            this.LogoPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.LogoPanel.Location = new System.Drawing.Point(0, 0);
            this.LogoPanel.Name = "LogoPanel";
            this.LogoPanel.Size = new System.Drawing.Size(204, 85);
            this.LogoPanel.TabIndex = 2;
            // 
            // page2_Input
            // 
            this.page2_Input.Controls.Add(this.pictureBox6);
            this.page2_Input.Controls.Add(this.textBox2);
            this.page2_Input.Controls.Add(this.metroDateTime2);
            this.page2_Input.Location = new System.Drawing.Point(204, 83);
            this.page2_Input.Name = "page2_Input";
            this.page2_Input.Size = new System.Drawing.Size(847, 469);
            this.page2_Input.TabIndex = 4;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(84, 116);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(276, 264);
            this.pictureBox6.TabIndex = 3;
            this.pictureBox6.TabStop = false;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox2.Location = new System.Drawing.Point(52, 42);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(138, 30);
            this.textBox2.TabIndex = 1;
            // 
            // metroDateTime2
            // 
            this.metroDateTime2.Location = new System.Drawing.Point(560, 42);
            this.metroDateTime2.MinimumSize = new System.Drawing.Size(4, 30);
            this.metroDateTime2.Name = "metroDateTime2";
            this.metroDateTime2.Size = new System.Drawing.Size(200, 30);
            this.metroDateTime2.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.metroGrid2);
            this.panel1.Controls.Add(this.metroDateTime3);
            this.panel1.Location = new System.Drawing.Point(204, 83);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(847, 469);
            this.panel1.TabIndex = 4;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(139, 85);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 25);
            this.textBox3.TabIndex = 6;
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(254, 87);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 5;
            this.button4.Text = "입력";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(46, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "목표 생산량";
            // 
            // metroGrid2
            // 
            this.metroGrid2.AllowUserToResizeRows = false;
            this.metroGrid2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle46.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle46.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle46.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle46.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle46.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle46;
            this.metroGrid2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle47.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle47.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle47.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle47.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid2.DefaultCellStyle = dataGridViewCellStyle47;
            this.metroGrid2.EnableHeadersVisualStyles = false;
            this.metroGrid2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid2.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid2.Location = new System.Drawing.Point(52, 192);
            this.metroGrid2.Name = "metroGrid2";
            this.metroGrid2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle48.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle48.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle48.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle48.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle48.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid2.RowHeadersDefaultCellStyle = dataGridViewCellStyle48;
            this.metroGrid2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid2.RowTemplate.Height = 27;
            this.metroGrid2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid2.Size = new System.Drawing.Size(708, 245);
            this.metroGrid2.TabIndex = 3;
            // 
            // metroDateTime3
            // 
            this.metroDateTime3.Location = new System.Drawing.Point(560, 156);
            this.metroDateTime3.MinimumSize = new System.Drawing.Size(4, 30);
            this.metroDateTime3.Name = "metroDateTime3";
            this.metroDateTime3.Size = new System.Drawing.Size(200, 30);
            this.metroDateTime3.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(39, 33);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // Smart
            // 
            this.Smart.AutoSize = true;
            this.Smart.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Smart.Location = new System.Drawing.Point(21, 38);
            this.Smart.Name = "Smart";
            this.Smart.Size = new System.Drawing.Size(172, 28);
            this.Smart.TabIndex = 0;
            this.Smart.Text = "Smart Factory";
            // 
            // HeadPanel
            // 
            this.HeadPanel.BackColor = System.Drawing.Color.DarkGray;
            this.HeadPanel.Controls.Add(this.User);
            this.HeadPanel.Controls.Add(this.pictureBox5);
            this.HeadPanel.Controls.Add(this.button6);
            this.HeadPanel.Controls.Add(this.button_exit);
            this.HeadPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.HeadPanel.Location = new System.Drawing.Point(204, 0);
            this.HeadPanel.Name = "HeadPanel";
            this.HeadPanel.Size = new System.Drawing.Size(847, 85);
            this.HeadPanel.TabIndex = 1;
            // 
            // User
            // 
            this.User.AutoSize = true;
            this.User.BackColor = System.Drawing.Color.DarkGray;
            this.User.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.User.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.User.Location = new System.Drawing.Point(84, 20);
            this.User.Name = "User";
            this.User.Size = new System.Drawing.Size(0, 0);
            this.User.TabIndex = 3;
            this.User.UseCustomBackColor = true;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(18, 20);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(31, 25);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 2;
            this.pictureBox5.TabStop = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.DarkGray;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(786, 3);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(26, 30);
            this.button6.TabIndex = 2;
            this.button6.Text = "-";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button_exit
            // 
            this.button_exit.BackColor = System.Drawing.Color.DarkGray;
            this.button_exit.FlatAppearance.BorderSize = 0;
            this.button_exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_exit.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_exit.Location = new System.Drawing.Point(818, 3);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(26, 30);
            this.button_exit.TabIndex = 0;
            this.button_exit.Text = "X";
            this.button_exit.UseVisualStyleBackColor = false;
            this.button_exit.Click += new System.EventHandler(this.button4_Click);
            // 
            // page1_Search
            // 
            this.page1_Search.Controls.Add(this.Page_SearchTab);
            this.page1_Search.Location = new System.Drawing.Point(204, 83);
            this.page1_Search.Name = "page1_Search";
            this.page1_Search.Size = new System.Drawing.Size(847, 469);
            this.page1_Search.TabIndex = 4;
            // 
            // Page_SearchTab
            // 
            this.Page_SearchTab.Controls.Add(this.Production_History);
            this.Page_SearchTab.Controls.Add(this.MonthlyStatus);
            this.Page_SearchTab.Controls.Add(this.dailyStatus);
            this.Page_SearchTab.Controls.Add(this.ProductionName);
            this.Page_SearchTab.Location = new System.Drawing.Point(0, 3);
            this.Page_SearchTab.Name = "Page_SearchTab";
            this.Page_SearchTab.SelectedIndex = 0;
            this.Page_SearchTab.Size = new System.Drawing.Size(847, 464);
            this.Page_SearchTab.TabIndex = 0;
            this.Page_SearchTab.UseCustomBackColor = true;
            this.Page_SearchTab.UseSelectable = true;
            this.Page_SearchTab.SelectedIndexChanged += new System.EventHandler(this.Page_SearchTab_SelectedIndexChanged);
            // 
            // Production_History
            // 
            this.Production_History.Controls.Add(this.ProductGrid);
            this.Production_History.Controls.Add(this.SerialSearch);
            this.Production_History.Controls.Add(this.SerialNum);
            this.Production_History.Controls.Add(this.ProductDateTime);
            this.Production_History.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Production_History.HorizontalScrollbarBarColor = true;
            this.Production_History.HorizontalScrollbarHighlightOnWheel = false;
            this.Production_History.HorizontalScrollbarSize = 10;
            this.Production_History.Location = new System.Drawing.Point(4, 38);
            this.Production_History.Name = "Production_History";
            this.Production_History.Size = new System.Drawing.Size(839, 422);
            this.Production_History.TabIndex = 0;
            this.Production_History.Text = "이력 조회     ";
            this.Production_History.VerticalScrollbarBarColor = true;
            this.Production_History.VerticalScrollbarHighlightOnWheel = false;
            this.Production_History.VerticalScrollbarSize = 10;
            // 
            // ProductGrid
            // 
            this.ProductGrid.AllowUserToResizeRows = false;
            this.ProductGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ProductGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ProductGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.ProductGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle49.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle49.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle49.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle49.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle49.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ProductGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle49;
            this.ProductGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle50.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle50.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle50.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle50.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle50.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle50.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ProductGrid.DefaultCellStyle = dataGridViewCellStyle50;
            this.ProductGrid.EnableHeadersVisualStyles = false;
            this.ProductGrid.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ProductGrid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ProductGrid.Location = new System.Drawing.Point(48, 86);
            this.ProductGrid.Name = "ProductGrid";
            this.ProductGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle51.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle51.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle51.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle51.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle51.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ProductGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle51;
            this.ProductGrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.ProductGrid.RowTemplate.Height = 27;
            this.ProductGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ProductGrid.Size = new System.Drawing.Size(716, 323);
            this.ProductGrid.TabIndex = 17;
            // 
            // SerialSearch
            // 
            this.SerialSearch.FlatAppearance.BorderSize = 0;
            this.SerialSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SerialSearch.Image = ((System.Drawing.Image)(resources.GetObject("SerialSearch.Image")));
            this.SerialSearch.Location = new System.Drawing.Point(192, 35);
            this.SerialSearch.Name = "SerialSearch";
            this.SerialSearch.Size = new System.Drawing.Size(43, 30);
            this.SerialSearch.TabIndex = 16;
            this.SerialSearch.UseVisualStyleBackColor = true;
            this.SerialSearch.Click += new System.EventHandler(this.SerialSearch_Click_1);
            // 
            // SerialNum
            // 
            this.SerialNum.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SerialNum.Location = new System.Drawing.Point(48, 35);
            this.SerialNum.Name = "SerialNum";
            this.SerialNum.Size = new System.Drawing.Size(138, 30);
            this.SerialNum.TabIndex = 15;
            // 
            // ProductDateTime
            // 
            this.ProductDateTime.Location = new System.Drawing.Point(556, 35);
            this.ProductDateTime.MinimumSize = new System.Drawing.Size(0, 30);
            this.ProductDateTime.Name = "ProductDateTime";
            this.ProductDateTime.Size = new System.Drawing.Size(208, 30);
            this.ProductDateTime.TabIndex = 14;
            this.ProductDateTime.ValueChanged += new System.EventHandler(this.ProductDateTime_ValueChanged_1);
            // 
            // MonthlyStatus
            // 
            this.MonthlyStatus.Controls.Add(this.label4);
            this.MonthlyStatus.Controls.Add(this.MonthlyProductionChart);
            this.MonthlyStatus.Controls.Add(this.SelectYear);
            this.MonthlyStatus.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.MonthlyStatus.HorizontalScrollbarBarColor = true;
            this.MonthlyStatus.HorizontalScrollbarHighlightOnWheel = false;
            this.MonthlyStatus.HorizontalScrollbarSize = 10;
            this.MonthlyStatus.Location = new System.Drawing.Point(4, 38);
            this.MonthlyStatus.Name = "MonthlyStatus";
            this.MonthlyStatus.Size = new System.Drawing.Size(839, 422);
            this.MonthlyStatus.TabIndex = 2;
            this.MonthlyStatus.Text = "월별 현황 조회     ";
            this.MonthlyStatus.VerticalScrollbarBarColor = true;
            this.MonthlyStatus.VerticalScrollbarHighlightOnWheel = false;
            this.MonthlyStatus.VerticalScrollbarSize = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(42, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 20);
            this.label4.TabIndex = 15;
            this.label4.Text = "Year";
            // 
            // MonthlyProductionChart
            // 
            chartArea7.Name = "ChartArea1";
            this.MonthlyProductionChart.ChartAreas.Add(chartArea7);
            legend7.Name = "Legend1";
            this.MonthlyProductionChart.Legends.Add(legend7);
            this.MonthlyProductionChart.Location = new System.Drawing.Point(45, 76);
            this.MonthlyProductionChart.Name = "MonthlyProductionChart";
            series7.ChartArea = "ChartArea1";
            series7.Legend = "Legend1";
            series7.Name = "Series1";
            this.MonthlyProductionChart.Series.Add(series7);
            this.MonthlyProductionChart.Size = new System.Drawing.Size(763, 321);
            this.MonthlyProductionChart.TabIndex = 14;
            this.MonthlyProductionChart.Text = "MonthlyProductionChart";
            // 
            // SelectYear
            // 
            this.SelectYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SelectYear.FormattingEnabled = true;
            this.SelectYear.Items.AddRange(new object[] {
            "2018",
            "2017",
            "2016"});
            this.SelectYear.Location = new System.Drawing.Point(115, 34);
            this.SelectYear.Name = "SelectYear";
            this.SelectYear.Size = new System.Drawing.Size(121, 28);
            this.SelectYear.TabIndex = 13;
            this.SelectYear.SelectedIndexChanged += new System.EventHandler(this.SelectYear_SelectedIndexChanged);
            // 
            // dailyStatus
            // 
            this.dailyStatus.Controls.Add(this.label3);
            this.dailyStatus.Controls.Add(this.dailyProductionChart);
            this.dailyStatus.Controls.Add(this.SelectMonth);
            this.dailyStatus.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.dailyStatus.HorizontalScrollbarBarColor = true;
            this.dailyStatus.HorizontalScrollbarHighlightOnWheel = false;
            this.dailyStatus.HorizontalScrollbarSize = 10;
            this.dailyStatus.Location = new System.Drawing.Point(4, 38);
            this.dailyStatus.Name = "dailyStatus";
            this.dailyStatus.Size = new System.Drawing.Size(839, 422);
            this.dailyStatus.TabIndex = 3;
            this.dailyStatus.Text = "일별 현황 조회     ";
            this.dailyStatus.VerticalScrollbarBarColor = true;
            this.dailyStatus.VerticalScrollbarHighlightOnWheel = false;
            this.dailyStatus.VerticalScrollbarSize = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(42, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 20);
            this.label3.TabIndex = 18;
            this.label3.Text = "Month";
            // 
            // dailyProductionChart
            // 
            chartArea8.Name = "ChartArea1";
            this.dailyProductionChart.ChartAreas.Add(chartArea8);
            legend8.Name = "Legend1";
            this.dailyProductionChart.Legends.Add(legend8);
            this.dailyProductionChart.Location = new System.Drawing.Point(45, 76);
            this.dailyProductionChart.Name = "dailyProductionChart";
            series8.ChartArea = "ChartArea1";
            series8.Legend = "Legend1";
            series8.Name = "Series1";
            this.dailyProductionChart.Series.Add(series8);
            this.dailyProductionChart.Size = new System.Drawing.Size(763, 321);
            this.dailyProductionChart.TabIndex = 17;
            this.dailyProductionChart.Text = "dailyProductionChart";
            // 
            // SelectMonth
            // 
            this.SelectMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SelectMonth.FormattingEnabled = true;
            this.SelectMonth.Items.AddRange(new object[] {
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12"});
            this.SelectMonth.Location = new System.Drawing.Point(115, 34);
            this.SelectMonth.Name = "SelectMonth";
            this.SelectMonth.Size = new System.Drawing.Size(121, 28);
            this.SelectMonth.TabIndex = 16;
            this.SelectMonth.SelectedIndexChanged += new System.EventHandler(this.SelectMonth_SelectedIndexChanged_2);
            // 
            // ProductionName
            // 
            this.ProductionName.Controls.Add(this.buttonRefresh);
            this.ProductionName.Controls.Add(this.ProductNameGrid);
            this.ProductionName.Controls.Add(this.label7);
            this.ProductionName.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.ProductionName.HorizontalScrollbarBarColor = true;
            this.ProductionName.HorizontalScrollbarHighlightOnWheel = false;
            this.ProductionName.HorizontalScrollbarSize = 10;
            this.ProductionName.Location = new System.Drawing.Point(4, 38);
            this.ProductionName.Name = "ProductionName";
            this.ProductionName.Size = new System.Drawing.Size(839, 422);
            this.ProductionName.TabIndex = 1;
            this.ProductionName.Text = "제품 조회     ";
            this.ProductionName.VerticalScrollbarBarColor = true;
            this.ProductionName.VerticalScrollbarHighlightOnWheel = false;
            this.ProductionName.VerticalScrollbarSize = 10;
            // 
            // buttonRefresh
            // 
            this.buttonRefresh.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.buttonRefresh.Location = new System.Drawing.Point(681, 39);
            this.buttonRefresh.Name = "buttonRefresh";
            this.buttonRefresh.Size = new System.Drawing.Size(88, 30);
            this.buttonRefresh.TabIndex = 15;
            this.buttonRefresh.Text = "새로고침";
            this.buttonRefresh.UseVisualStyleBackColor = true;
            this.buttonRefresh.Click += new System.EventHandler(this.buttonRefresh_Click);
            // 
            // ProductNameGrid
            // 
            this.ProductNameGrid.AllowUserToResizeRows = false;
            this.ProductNameGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ProductNameGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ProductNameGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.ProductNameGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle52.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle52.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle52.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle52.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle52.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle52.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ProductNameGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle52;
            this.ProductNameGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle53.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle53.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle53.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle53.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle53.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ProductNameGrid.DefaultCellStyle = dataGridViewCellStyle53;
            this.ProductNameGrid.EnableHeadersVisualStyles = false;
            this.ProductNameGrid.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ProductNameGrid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ProductNameGrid.Location = new System.Drawing.Point(28, 115);
            this.ProductNameGrid.Name = "ProductNameGrid";
            this.ProductNameGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle54.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle54.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle54.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle54.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle54.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle54.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ProductNameGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle54;
            this.ProductNameGrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.ProductNameGrid.RowTemplate.Height = 27;
            this.ProductNameGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ProductNameGrid.Size = new System.Drawing.Size(780, 289);
            this.ProductNameGrid.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("맑은 고딕", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.Location = new System.Drawing.Point(20, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 32);
            this.label7.TabIndex = 13;
            this.label7.Text = "제품 조회";
            // 
            // page2_line
            // 
            this.page2_line.Controls.Add(this.Page_planTab);
            this.page2_line.Location = new System.Drawing.Point(204, 83);
            this.page2_line.Name = "page2_line";
            this.page2_line.Size = new System.Drawing.Size(847, 469);
            this.page2_line.TabIndex = 11;
            // 
            // Page_planTab
            // 
            this.Page_planTab.Controls.Add(this.PlanInsert);
            this.Page_planTab.Controls.Add(this.Operating_situation);
            this.Page_planTab.Location = new System.Drawing.Point(0, 3);
            this.Page_planTab.Name = "Page_planTab";
            this.Page_planTab.SelectedIndex = 0;
            this.Page_planTab.Size = new System.Drawing.Size(847, 466);
            this.Page_planTab.TabIndex = 0;
            this.Page_planTab.UseCustomBackColor = true;
            this.Page_planTab.UseSelectable = true;
            this.Page_planTab.SelectedIndexChanged += new System.EventHandler(this.Page_planTab_SelectedIndexChanged_1);
            // 
            // PlanInsert
            // 
            this.PlanInsert.Controls.Add(this.Delete_Plan);
            this.PlanInsert.Controls.Add(this.SelectProductionLine);
            this.PlanInsert.Controls.Add(this.label6);
            this.PlanInsert.Controls.Add(this.LinePlanGrid);
            this.PlanInsert.Controls.Add(this.button2);
            this.PlanInsert.Controls.Add(this.Line_num);
            this.PlanInsert.Controls.Add(this.label5);
            this.PlanInsert.Controls.Add(this.Line_Product);
            this.PlanInsert.Controls.Add(this.label2);
            this.PlanInsert.HorizontalScrollbarBarColor = true;
            this.PlanInsert.HorizontalScrollbarHighlightOnWheel = false;
            this.PlanInsert.HorizontalScrollbarSize = 10;
            this.PlanInsert.Location = new System.Drawing.Point(4, 38);
            this.PlanInsert.Name = "PlanInsert";
            this.PlanInsert.Size = new System.Drawing.Size(839, 424);
            this.PlanInsert.TabIndex = 0;
            this.PlanInsert.Text = "계획 입력 조회      ";
            this.PlanInsert.VerticalScrollbarBarColor = true;
            this.PlanInsert.VerticalScrollbarHighlightOnWheel = false;
            this.PlanInsert.VerticalScrollbarSize = 10;
            // 
            // Delete_Plan
            // 
            this.Delete_Plan.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Delete_Plan.Location = new System.Drawing.Point(677, 370);
            this.Delete_Plan.Name = "Delete_Plan";
            this.Delete_Plan.Size = new System.Drawing.Size(113, 32);
            this.Delete_Plan.TabIndex = 10;
            this.Delete_Plan.Text = "예약 취소";
            this.Delete_Plan.UseVisualStyleBackColor = true;
            this.Delete_Plan.Click += new System.EventHandler(this.Delete_Plan_Click_1);
            // 
            // SelectProductionLine
            // 
            this.SelectProductionLine.FormattingEnabled = true;
            this.SelectProductionLine.ItemHeight = 24;
            this.SelectProductionLine.Items.AddRange(new object[] {
            "1번라인"});
            this.SelectProductionLine.Location = new System.Drawing.Point(314, 35);
            this.SelectProductionLine.Name = "SelectProductionLine";
            this.SelectProductionLine.Size = new System.Drawing.Size(121, 30);
            this.SelectProductionLine.TabIndex = 9;
            this.SelectProductionLine.UseSelectable = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(224, 39);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 23);
            this.label6.TabIndex = 8;
            this.label6.Text = "생산 라인";
            // 
            // LinePlanGrid
            // 
            this.LinePlanGrid.AllowUserToResizeRows = false;
            this.LinePlanGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.LinePlanGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.LinePlanGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.LinePlanGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle55.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle55.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle55.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle55.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle55.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle55.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.LinePlanGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle55;
            this.LinePlanGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle56.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle56.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle56.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle56.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle56.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle56.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle56.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.LinePlanGrid.DefaultCellStyle = dataGridViewCellStyle56;
            this.LinePlanGrid.EnableHeadersVisualStyles = false;
            this.LinePlanGrid.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.LinePlanGrid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.LinePlanGrid.Location = new System.Drawing.Point(35, 88);
            this.LinePlanGrid.Name = "LinePlanGrid";
            this.LinePlanGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle57.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle57.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle57.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle57.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle57.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle57.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.LinePlanGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle57;
            this.LinePlanGrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.LinePlanGrid.RowTemplate.Height = 27;
            this.LinePlanGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.LinePlanGrid.Size = new System.Drawing.Size(755, 276);
            this.LinePlanGrid.TabIndex = 7;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button2.Location = new System.Drawing.Point(662, 34);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 32);
            this.button2.TabIndex = 6;
            this.button2.Text = "입력";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // Line_num
            // 
            this.Line_num.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Line_num.Location = new System.Drawing.Point(507, 36);
            this.Line_num.Name = "Line_num";
            this.Line_num.Size = new System.Drawing.Size(100, 30);
            this.Line_num.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(457, 39);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 23);
            this.label5.TabIndex = 4;
            this.label5.Text = "수량";
            // 
            // Line_Product
            // 
            this.Line_Product.FormattingEnabled = true;
            this.Line_Product.ItemHeight = 24;
            this.Line_Product.Items.AddRange(new object[] {
            "WHITE"});
            this.Line_Product.Location = new System.Drawing.Point(81, 35);
            this.Line_Product.Name = "Line_Product";
            this.Line_Product.Size = new System.Drawing.Size(121, 30);
            this.Line_Product.TabIndex = 3;
            this.Line_Product.UseSelectable = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(31, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 23);
            this.label2.TabIndex = 2;
            this.label2.Text = "제품";
            // 
            // Operating_situation
            // 
            this.Operating_situation.Controls.Add(this.pictureBox10);
            this.Operating_situation.Controls.Add(this.label12);
            this.Operating_situation.Controls.Add(this.pictureBox9);
            this.Operating_situation.Controls.Add(this.label11);
            this.Operating_situation.Controls.Add(this.pictureBox8);
            this.Operating_situation.Controls.Add(this.label10);
            this.Operating_situation.Controls.Add(this.pictureBox7);
            this.Operating_situation.Controls.Add(this.label9);
            this.Operating_situation.HorizontalScrollbarBarColor = true;
            this.Operating_situation.HorizontalScrollbarHighlightOnWheel = false;
            this.Operating_situation.HorizontalScrollbarSize = 10;
            this.Operating_situation.Location = new System.Drawing.Point(4, 38);
            this.Operating_situation.Name = "Operating_situation";
            this.Operating_situation.Size = new System.Drawing.Size(839, 424);
            this.Operating_situation.TabIndex = 1;
            this.Operating_situation.Text = "라인 가동 상황     ";
            this.Operating_situation.VerticalScrollbarBarColor = true;
            this.Operating_situation.VerticalScrollbarHighlightOnWheel = false;
            this.Operating_situation.VerticalScrollbarSize = 10;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Location = new System.Drawing.Point(201, 204);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(43, 32);
            this.pictureBox10.TabIndex = 23;
            this.pictureBox10.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("맑은 고딕", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label12.Location = new System.Drawing.Point(20, 204);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 32);
            this.label12.TabIndex = 22;
            this.label12.Text = "3번라인";
            // 
            // pictureBox9
            // 
            this.pictureBox9.Location = new System.Drawing.Point(630, 204);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(43, 32);
            this.pictureBox9.TabIndex = 21;
            this.pictureBox9.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("맑은 고딕", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label11.Location = new System.Drawing.Point(449, 204);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(101, 32);
            this.label11.TabIndex = 20;
            this.label11.Text = "4번라인";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Location = new System.Drawing.Point(630, 27);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(43, 32);
            this.pictureBox8.TabIndex = 19;
            this.pictureBox8.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("맑은 고딕", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label10.Location = new System.Drawing.Point(449, 27);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(101, 32);
            this.label10.TabIndex = 18;
            this.label10.Text = "2번라인";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Location = new System.Drawing.Point(201, 27);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(43, 32);
            this.pictureBox7.TabIndex = 17;
            this.pictureBox7.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("맑은 고딕", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label9.Location = new System.Drawing.Point(20, 27);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(101, 32);
            this.label9.TabIndex = 13;
            this.label9.Text = "1번라인";
            // 
            // Page0_Notice
            // 
            this.Page0_Notice.Controls.Add(this.label8);
            this.Page0_Notice.Controls.Add(this.NoticeNote);
            this.Page0_Notice.Controls.Add(this.NoticeSend);
            this.Page0_Notice.Controls.Add(this.NoticeGrid);
            this.Page0_Notice.Location = new System.Drawing.Point(12, 469);
            this.Page0_Notice.Name = "Page0_Notice";
            this.Page0_Notice.Size = new System.Drawing.Size(847, 469);
            this.Page0_Notice.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("맑은 고딕", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label8.Location = new System.Drawing.Point(26, 21);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(119, 32);
            this.label8.TabIndex = 12;
            this.label8.Text = "공지 사항";
            // 
            // NoticeNote
            // 
            this.NoticeNote.Location = new System.Drawing.Point(30, 326);
            this.NoticeNote.Name = "NoticeNote";
            this.NoticeNote.Size = new System.Drawing.Size(699, 131);
            this.NoticeNote.TabIndex = 11;
            this.NoticeNote.Text = "";
            this.NoticeNote.KeyDown += new System.Windows.Forms.KeyEventHandler(this.NoticeNote_KeyDown);
            // 
            // NoticeSend
            // 
            this.NoticeSend.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.NoticeSend.Image = ((System.Drawing.Image)(resources.GetObject("NoticeSend.Image")));
            this.NoticeSend.Location = new System.Drawing.Point(743, 326);
            this.NoticeSend.Name = "NoticeSend";
            this.NoticeSend.Size = new System.Drawing.Size(69, 131);
            this.NoticeSend.TabIndex = 8;
            this.NoticeSend.Text = "보내기";
            this.NoticeSend.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.NoticeSend.UseVisualStyleBackColor = true;
            this.NoticeSend.Click += new System.EventHandler(this.NoticeSend_Click);
            // 
            // NoticeGrid
            // 
            this.NoticeGrid.AllowUserToResizeRows = false;
            this.NoticeGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.NoticeGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.NoticeGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.NoticeGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle58.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle58.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle58.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle58.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle58.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle58.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle58.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.NoticeGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle58;
            this.NoticeGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle59.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle59.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle59.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle59.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle59.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle59.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle59.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.NoticeGrid.DefaultCellStyle = dataGridViewCellStyle59;
            this.NoticeGrid.EnableHeadersVisualStyles = false;
            this.NoticeGrid.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.NoticeGrid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.NoticeGrid.Location = new System.Drawing.Point(30, 72);
            this.NoticeGrid.Name = "NoticeGrid";
            this.NoticeGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle60.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle60.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle60.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle60.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle60.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle60.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle60.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.NoticeGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle60;
            this.NoticeGrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.NoticeGrid.RowTemplate.Height = 27;
            this.NoticeGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.NoticeGrid.Size = new System.Drawing.Size(782, 232);
            this.NoticeGrid.TabIndex = 5;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1051, 552);
            this.Controls.Add(this.Page0_Notice);
            this.Controls.Add(this.page2_line);
            this.Controls.Add(this.page1_Search);
            this.Controls.Add(this.HeadPanel);
            this.Controls.Add(this.SidePanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Home";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.SidePanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.LogoPanel.ResumeLayout(false);
            this.LogoPanel.PerformLayout();
            this.page2_Input.ResumeLayout(false);
            this.page2_Input.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.HeadPanel.ResumeLayout(false);
            this.HeadPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.page1_Search.ResumeLayout(false);
            this.Page_SearchTab.ResumeLayout(false);
            this.Production_History.ResumeLayout(false);
            this.Production_History.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ProductGrid)).EndInit();
            this.MonthlyStatus.ResumeLayout(false);
            this.MonthlyStatus.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MonthlyProductionChart)).EndInit();
            this.dailyStatus.ResumeLayout(false);
            this.dailyStatus.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dailyProductionChart)).EndInit();
            this.ProductionName.ResumeLayout(false);
            this.ProductionName.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ProductNameGrid)).EndInit();
            this.page2_line.ResumeLayout(false);
            this.Page_planTab.ResumeLayout(false);
            this.PlanInsert.ResumeLayout(false);
            this.PlanInsert.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LinePlanGrid)).EndInit();
            this.Operating_situation.ResumeLayout(false);
            this.Operating_situation.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.Page0_Notice.ResumeLayout(false);
            this.Page0_Notice.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NoticeGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel SidePanel;
        private System.Windows.Forms.Panel LogoPanel;
        private System.Windows.Forms.Label Smart;
        private System.Windows.Forms.Panel HeadPanel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_search;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.Panel page2_Input;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.TextBox textBox2;
        private MetroFramework.Controls.MetroDateTime metroDateTime2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label1;
        private MetroFramework.Controls.MetroGrid metroGrid2;
        private MetroFramework.Controls.MetroDateTime metroDateTime3;
        private MetroFramework.Components.MetroStyleExtender metroStyleExtender1;
        private System.Windows.Forms.Panel page1_Search;
        private MetroFramework.Controls.MetroTabControl Page_SearchTab;
        private MetroFramework.Controls.MetroTabPage ProductionName;
        private MetroFramework.Controls.MetroTabPage Production_History;
        private MetroFramework.Controls.MetroGrid ProductGrid;
        private System.Windows.Forms.Button SerialSearch;
        private System.Windows.Forms.TextBox SerialNum;
        private MetroFramework.Controls.MetroDateTime ProductDateTime;
        private MetroFramework.Controls.MetroTabPage dailyStatus;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataVisualization.Charting.Chart dailyProductionChart;
        private System.Windows.Forms.ComboBox SelectMonth;
        private MetroFramework.Controls.MetroTabPage MonthlyStatus;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataVisualization.Charting.Chart MonthlyProductionChart;
        private System.Windows.Forms.ComboBox SelectYear;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button button_plan;
        private System.Windows.Forms.Panel page2_line;
        private MetroFramework.Controls.MetroTabControl Page_planTab;
        private MetroFramework.Controls.MetroTabPage PlanInsert;
        private System.Windows.Forms.Button Delete_Plan;
        private MetroFramework.Controls.MetroComboBox SelectProductionLine;
        private System.Windows.Forms.Label label6;
        private MetroFramework.Controls.MetroGrid LinePlanGrid;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox Line_num;
        private System.Windows.Forms.Label label5;
        private MetroFramework.Controls.MetroComboBox Line_Product;
        private System.Windows.Forms.Label label2;
        private MetroFramework.Controls.MetroTabPage Operating_situation;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button button_Notice;
        private System.Windows.Forms.Panel Page0_Notice;
        private MetroFramework.Controls.MetroGrid NoticeGrid;
        private System.Windows.Forms.RichTextBox NoticeNote;
        private System.Windows.Forms.Button NoticeSend;
        private MetroFramework.Controls.MetroLabel User;
        private System.Windows.Forms.Label label8;
        private MetroFramework.Controls.MetroGrid ProductNameGrid;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button buttonRefresh;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox7;
    }
}

